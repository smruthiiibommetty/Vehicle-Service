<?php
session_start();
require 'dbcon.php';

if(isset($_POST['delete_category']))
{
    $id = mysqli_real_escape_string($con, $_POST['delete_category']);

    $query = "DELETE FROM category_list WHERE id='$id'";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "category Deleted Successfully";
        header("Location: indexcat.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "category Not Deleted";
        header("Location: indexcat.php");
        exit(0);
    }
}


if(isset($_POST['update_cat']))
{
    $id = mysqli_real_escape_string($con, $_POST['id']);

    $category = mysqli_real_escape_string($con, $_POST['category']);
   

    $query = "UPDATE category_list SET category='$category' WHERE id='$id'";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "category Updated Successfully";
        header("Location: indexcat.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "category Not Updated";
        header("Location: indexcat.php");
        exit(0);
    }

}





if(isset($_POST['save_category']))
{
    $category = mysqli_real_escape_string($con, $_POST['category']);
    
    $query = "INSERT INTO category_list (category) VALUES ('$category')";

    $query_run = mysqli_query($con, $query);
    if($query_run)
    {
        $_SESSION['message'] = "category Created Successfully";
        header("Location: indexcat.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "category Not Created";
        header("Location: indexcat.php");
        exit(0);
    }
}

?>
