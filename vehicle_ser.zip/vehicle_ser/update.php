<?php
session_start();
require 'dbcon.php';

if(isset($_POST['update_category']))
{
    $id = mysqli_real_escape_string($con, $_POST['id']);

    $catagory = mysqli_real_escape_string($con, $_POST['category']);
    

    $query = "UPDATE category_list SET category='$category' WHERE id='$id' ";
    $query_run = mysqli_query($con, $query);    

    if($query_run)
    {
        $_SESSION['message'] = "Updated Successfully";
        header("Location: indexcat.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = " Not Updated";
        header("Location: indexcat.php");
        exit(0);
    }

}
?>